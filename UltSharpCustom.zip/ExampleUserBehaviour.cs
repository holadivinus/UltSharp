﻿using SLZ.Marrow;
using UnityEngine;

namespace UltSharpCustom
{
    public class ExampleUserBehaviour : UltBehaviour
    {
        // hi hello
        // any script that derives from this ^^^
        // should show up in unity as a dropdown item in the "Ult Sharp Script" component
        // CTRL+B builds & sends the code over to unity, updating scripts in the open scene.


        // some example variables
        public float MyVariable = 5.55f;
        public bool John6 = true;
        public int AppleCount = 22;
        public string Name = "Joey";

        
        // this attribute is for object variables that won't change ingame;
        // [think Transform, Gun, BoxCollider, MeshRenderer]
        // It lets the generated ult-events mess with the object directly, obj.stuff() happens in 1 call
        [RuntimeConstant] public SkinnedMeshRenderer Alien;

        // this attribute is like RuntimeConstant but you are allowed to change it
        // however changing it is a lag spike
        // good for something you'd find once, and then mess with for a while
        [UltSwap] Gun FoundWeapon;


        public override void OnStart()
        {
            Debug.Log("those who start");
        }
        public override void Update()
        {
            Debug.Log("spam");
        }
        public override void OnDestroy()
        {
            Debug.Log("death");
        }

        public void Eat5Apples()
        {
            EatApples(5);
        }


        public int EatApples(int howMany)
        {
            AppleCount -= howMany;
            Debug.Log($"{Name} ate {howMany} apples, and has {AppleCount} left.");

            if ( AppleCount < 0)
            {
                Debug.Log("holy moly, negative apples");
            } else
            {
                if (Alien)
                    Debug.Log($"the alien has {Alien.bones.Length} bones");
                else Debug.Log("aliens arent real.");
            }

            return AppleCount;
        }
    }
}
     